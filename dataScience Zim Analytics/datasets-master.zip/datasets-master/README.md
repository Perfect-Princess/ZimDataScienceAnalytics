# datasets
Collection of datasets for the Open Data initiative. 
